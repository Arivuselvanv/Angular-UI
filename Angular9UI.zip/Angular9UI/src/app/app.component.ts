import { Component } from '@angular/core';
import {ServiceService} from './service.service';
import { FormGroup, FormControl,Validators } from '@angular/forms'; 
import { MatDialog } from '@angular/material/dialog';
import { MyModalComponent } from './my-modal/my-modal.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EmployeeFrontEnd';

  city: string;
  name: string;
  food_from_modal: string;
   
  constructor(private ServiceService: ServiceService,public dialog: MatDialog) { }
  data: any;
  EmpForm: FormGroup;
  submitted = false; 
  EventValue: any = "Save";

  ngOnInit(): void {
    this.getdata();

    this.EmpForm = new FormGroup({
      empId: new FormControl(null),
      empName: new FormControl("",[Validators.required]),      
      empContact: new FormControl("",[Validators.required]),
      empEmail:new FormControl("",[Validators.required]),
      empAddress: new FormControl("",[Validators.required]),
    })  
  }
  getdata() {
    this.ServiceService.getData().subscribe((data: any[]) => {
      this.data = data;
    })
  }
  deleteData(id) {
    this.ServiceService.deleteData(id).subscribe((data: any[]) => {
      this.data = data;
      this.getdata();
    })
  }
  Save() { 
    this.submitted = true;
  
     if (this.EmpForm.invalid) {
            return;
     }
    this.ServiceService.postData(this.EmpForm.value).subscribe((data: any[]) => {
      this.data = data;
      this.resetFrom();

    })
  }
  Update() { 
    this.submitted = true;
  
    if (this.EmpForm.invalid) {
     return;
    }      
    this.ServiceService.putData(this.EmpForm.value.empId,this.EmpForm.value).subscribe((data: any[]) => {
      this.data = data;
      this.resetFrom();
    })
  }

  EditData(Data) {
    this.EmpForm.controls["empId"].setValue(Data.empId);
    this.EmpForm.controls["empName"].setValue(Data.empName);    
    this.EmpForm.controls["empContact"].setValue(Data.empContact);
    this.EmpForm.controls["empEmail"].setValue(Data.empEmail);
    this.EmpForm.controls["empAddress"].setValue(Data.empAddress);
    this.EventValue = "Update";
  }

  resetFrom()
  {   
    this.getdata();
    this.EmpForm.reset();
    this.EventValue = "Save";
    this.submitted = false; 
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(MyModalComponent, {
      width: '250px',
      data: { name: this.name, city: this.city }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      this.city = result;
      this.food_from_modal = result.food;
    });
  }

}
